package proyecto.tienda.de.refacciones.Clases;

public class Vendedor extends Empleado {
    
    public Vendedor(){}

    public Vendedor(String Usuario, String Contrasenia, float Sueldo, int DiasDescanso, String Puesto, String Observaciones, String Nombre, String ApellidoPaterno, String ApellidoMaterno, String CorreoElectronico, int Telefono) {
        super(Usuario, Contrasenia, Sueldo, DiasDescanso, Puesto, Observaciones, Nombre, ApellidoPaterno, ApellidoMaterno, CorreoElectronico, Telefono);
    }
    
   
    
}
