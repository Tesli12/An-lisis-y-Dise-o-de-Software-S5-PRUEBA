/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tiendadeabarrotes_Archivo;

import tiendadeabarrotes_Clases.Proveedor;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;



public class ArchivoProveedor {
    static String data = "src/archivos/Poveedores.txt";
   
    public static void crearArchivos(ArrayList lista){  
    FileWriter flwriter = null;
        try{
            flwriter = new FileWriter(data);
            
             BufferedWriter bfwriter = new BufferedWriter(flwriter);
             for(Proveedor proveedor: (ArrayList<Proveedor>)lista){
                  bfwriter.write(proveedor.getID_Proveedor()+","+proveedor.getNombre()+","+proveedor.getAPaterno()+","+proveedor.getAMaterno()+","+proveedor.getTelefono()+","+
                          proveedor.getCorreo()+","+proveedor.getDiaEntrega()+","+proveedor.getHoraEntrega()+","+"\n");
                   
             }
             bfwriter.close();
             System.out.println("Archivo creado con exito......");
             
        }catch(IOException e){
            e.printStackTrace();
        }finally{
            if(flwriter != null){
                try{
                  flwriter.close();   
                }catch(IOException e){
                  e.printStackTrace();
                }     
            }
        }
    }
    
    
    
    public static ArrayList leerArchivo(){
    File file = new File(data);
    ArrayList listaProveedores = new ArrayList();
    Scanner scanner;
    try{
       scanner = new Scanner(file);
       while(scanner.hasNextLine()){
           String linea = scanner.nextLine();
           Scanner delimitar = new Scanner(linea);
           delimitar.useDelimiter("\\s*,\\s*");
           
           Proveedor c = new Proveedor();
           
           c.setID_Proveedor(delimitar.nextInt());
           c.setNombre(delimitar.next());
           c.setAPaterno(delimitar.next());
           c.setAMaterno(delimitar.next());
           c.setTelefono(delimitar.nextInt());
           c.setCorreo(delimitar.next());
           c.setDiaEntrega(delimitar.next());
           c.setHoraEntrega(delimitar.next());
           
           listaProveedores.add(c);
           
       }
       scanner.close();
       
    }catch(FileNotFoundException e){
          e.printStackTrace();
    }
       
    return listaProveedores;
    
    }
    
    public static void aniadirArchivo (ArrayList lista){
    FileWriter flwriter = null;
    try{
         flwriter = new FileWriter(data, true);
             BufferedWriter bfwriter = new BufferedWriter(flwriter);
             for(Proveedor proveedor: (ArrayList<Proveedor>)lista){
                  bfwriter.write(proveedor.getID_Proveedor()+","+proveedor.getNombre()+","+proveedor.getAPaterno()+","+proveedor.getAMaterno()+","+proveedor.getTelefono()+","+
                          proveedor.getCorreo()+","+proveedor.getDiaEntrega()+","+proveedor.getHoraEntrega()+","+"\n");
                   
             }
             bfwriter.close();
             System.out.println("Archivo creado con exito......");
             
    }catch(IOException e){
            e.printStackTrace();
        }finally{
            if(flwriter != null){
                try{
                  flwriter.close();   
                }catch(IOException e){
                  e.printStackTrace();
                }     
            }
        }
    }
    
    public static void Modificar (ArrayList lista){
         FileWriter flwriter = null;
    try{
         flwriter = new FileWriter(data);
             BufferedWriter bfwriter = new BufferedWriter(flwriter);
             for(Proveedor proveedor: (ArrayList<Proveedor>)lista){
                 bfwriter.write(proveedor.getID_Proveedor()+","+proveedor.getNombre()+","+proveedor.getAPaterno()+","+proveedor.getAMaterno()+","+proveedor.getTelefono()+","+
                          proveedor.getCorreo()+","+proveedor.getDiaEntrega()+","+proveedor.getHoraEntrega()+","+"\n");
                   
             }
             bfwriter.close();
             System.out.println("Archivo creado con exito......");
             
    }catch(IOException e){
            e.printStackTrace();
        }finally{
            if(flwriter != null){
                try{
                  flwriter.close();   
                }catch(IOException e){
                  e.printStackTrace();
                }     
            }
        }
        
        
        
    }
    
    
    
}
