package tiendadeabarrotes_Clases;

public class Vendedor extends Empleado {
    
    public Vendedor(){}

    public Vendedor(String Usuario, String Contrasenia, float Sueldo,String  Rol, String Puesto, String Observaciones, String Nombre, String ApellidoPaterno, String ApellidoMaterno, String CorreoElectronico, int Telefono) {
        super(Usuario, Contrasenia, Sueldo, Rol, Puesto, Observaciones, Nombre, ApellidoPaterno, ApellidoMaterno, CorreoElectronico, Telefono);
    }
    
   
    
   
}
