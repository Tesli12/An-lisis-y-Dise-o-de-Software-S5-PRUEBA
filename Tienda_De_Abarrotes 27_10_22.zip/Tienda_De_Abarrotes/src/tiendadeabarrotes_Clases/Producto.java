
package tiendadeabarrotes_Clases;

public class Producto {


    private String Estado;
    private int Cantidad;
    private String NombreP;
    private String Descripcion;
    private float Precio;
    private float PrecioIn;
    private int ID_Producto;
    private String Ubicacion;
    private String IDProveedor;
    
    public Producto(){}

    Producto(String Estado, int Cantidad, String NombreP, String Descripcion, float Precio,float PrecioIn,int ID_Producto) {
        this.Estado = Estado;
        this.Cantidad = Cantidad;
        this.NombreP = NombreP;
        this.Descripcion = Descripcion;
        this.Precio = Precio;
        this.PrecioIn = PrecioIn;
        this.ID_Producto=ID_Producto;
    }
    
        /**
     * @return the Estado
     */
    public String getEstado() {
        return Estado;
    }

    /**
     * @param Estado the Estado to set
     */
    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    /**
     * @return the Cantidad
     */
    public int getCantidad() {
        return Cantidad;
    }

    /**
     * @param Cantidad the Cantidad to set
     */
    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }

    /**
     * @return the NombreP
     */
    public String getNombreP() {
        return NombreP;
    }

    /**
     * @param NombreP the NombreP to set
     */
    public void setNombreP(String NombreP) {
        this.NombreP = NombreP;
    }

    /**
     * @return the Descripcion
     */
    public String getDescripcion() {
        return Descripcion;
    }

    /**
     * @param Descripcion the Descripcion to set
     */
    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    /**
     * @return the Precio
     */
    public float getPrecio() {
        return Precio;
    }

    /**
     * @param Precio the Precio to set
     */
    public void setPrecio(float Precio) {
        this.Precio = Precio;
    }

    /**
     * @return the PrecioIn
     */
    public float getPrecioIn() {
        return PrecioIn;
    }

    /**
     * @param PrecioIn the PrecioIn to set
     */
    public void setPrecioIn(float PrecioIn) {
        this.PrecioIn = PrecioIn;
    }

    /**
     * @return the ID_Producto
     */
    public int getID_Producto() {
        return ID_Producto;
    }

    /**
     * @param ID_Producto the ID_Producto to set
     */
    public void setID_Producto(int ID_Producto) {
        this.ID_Producto = ID_Producto;
    }
    
    
}
