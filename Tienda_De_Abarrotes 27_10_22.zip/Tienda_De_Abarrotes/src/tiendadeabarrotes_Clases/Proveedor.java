
package tiendadeabarrotes_Clases;

public class Proveedor {

    private int ID_Proveedor;
    private String Nombre;
    private String APaterno;
    private String AMaterno;
    private int Telefono;
    private String Correo;
    private String DiaEntrega;
    private String HoraEntrega;
    
    public Proveedor(){}
    
    public Proveedor (int ID_Proveedor,String Nombre,String APaterno,String AMaterno,int Telefono,String Correo,String DiaEntrega,String HoraEntrega){
        this.ID_Proveedor=ID_Proveedor;
        this.Nombre=Nombre;
        this.APaterno=APaterno;
        this.Telefono=Telefono;
        this.Correo=Correo;
        this.DiaEntrega=DiaEntrega;
        this.HoraEntrega=HoraEntrega;
    }
    /**
     * @return the DiaEntrega
     */
    public String getDiaEntrega() {
        return DiaEntrega;
    }

    /**
     * @param DiaEntrega the DiaEntrega to set
     */
    public void setDiaEntrega(String DiaEntrega) {
        this.DiaEntrega = DiaEntrega;
    }

    /**
     * @return the HoraEntrega
     */
    public String getHoraEntrega() {
        return HoraEntrega;
    }

    /**
     * @param HoraEntrega the HoraEntrega to set
     */
    public void setHoraEntrega(String HoraEntrega) {
        this.HoraEntrega = HoraEntrega;
    }
    /**
     * @return the ID_Proveedor
     */
    public int getID_Proveedor() {
        return ID_Proveedor;
    }

    /**
     * @param ID_Proveedor the ID_Provedor to set
     */
    public void setID_Proveedor(int ID_Proveedor) {
        this.ID_Proveedor = ID_Proveedor;
    }

    /**
     * @return the Nombre
     */
    public String getNombre() {
        return Nombre;
    }

    /**
     * @param Nombre the Nombre to set
     */
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    /**
     * @return the APaterno
     */
    public String getAPaterno() {
        return APaterno;
    }

    /**
     * @param APaterno the APaterno to set
     */
    public void setAPaterno(String APaterno) {
        this.APaterno = APaterno;
    }

    /**
     * @return the AMaterno
     */
    public String getAMaterno() {
        return AMaterno;
    }

    /**
     * @param AMaterno the AMaterno to set
     */
    public void setAMaterno(String AMaterno) {
        this.AMaterno = AMaterno;
    }

    /**
     * @return the Telefono
     */
    public int getTelefono() {
        return Telefono;
    }

    /**
     * @param Telefono the Telefono to set
     */
    public void setTelefono(int Telefono) {
        this.Telefono = Telefono;
    }

    /**
     * @return the Correo
     */
    public String getCorreo() {
        return Correo;
    }

    /**
     * @param Correo the Correo to set
     */
    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

  

    
    
}
